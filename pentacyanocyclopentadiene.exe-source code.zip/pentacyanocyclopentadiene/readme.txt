pentacyanocyclopentadiene by pankoza and UltraDasher965
This is our first collab malware, and pankoza's second collab after xml.exe collab with fr4ctalz back in 2023
Credits to Malsteve527 for the Hue Function and credits to EthernalVortex for PRGBQUAD
Credits to sapphiretech for the icons payload in the 3rd payload

This is a malware, Creators are not responsible for any damage, do not run if you have epilepsy or heart issues.
This is very dangerous for the non-safety version, the non-safety version will overwrite the MBR and will make your PC unbootable.

Created on 14 February 2026.