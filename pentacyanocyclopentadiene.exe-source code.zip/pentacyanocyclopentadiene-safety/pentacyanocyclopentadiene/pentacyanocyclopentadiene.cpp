// pentacyanocyclopentadiene.cpp : malware collab between pankoza and UltraDasher965
//

#include <Windows.h>
#pragma comment(lib, "winmm.lib")
#pragma comment(lib,"Msimg32.lib")
#include <math.h>
#include <tchar.h>
#include <cstdint>
#include <cstdlib>
#define M_PI   3.14159265358979323846264338327950288

typedef union _RGBQUAD {
	COLORREF rgb;
	struct {
		BYTE b;
		BYTE g;
		BYTE r;
		BYTE Reserved;
	};
}_RGBQUAD, * PRGBQUAD;
typedef NTSTATUS(NTAPI* NRHEdef)(NTSTATUS, ULONG, ULONG, PULONG, ULONG, PULONG);
typedef NTSTATUS(NTAPI* RAPdef)(ULONG, BOOLEAN, BOOLEAN, PBOOLEAN);
typedef struct
{
	FLOAT h;
	FLOAT s;
	FLOAT l;
} HSL;

namespace Colors
{
	//These HSL functions was made by Wipet, credits to him!
	//OBS: I used it in 3 payloads

	//Btw ArTicZera created HSV functions, but it sucks unfortunatelly
	//So I didn't used in this malware.

	HSL rgb2hsl(RGBQUAD rgb)
	{
		HSL hsl;

		BYTE r = rgb.rgbRed;
		BYTE g = rgb.rgbGreen;
		BYTE b = rgb.rgbBlue;

		FLOAT _r = (FLOAT)r / 255.f;
		FLOAT _g = (FLOAT)g / 255.f;
		FLOAT _b = (FLOAT)b / 255.f;

		FLOAT rgbMin = min(min(_r, _g), _b);
		FLOAT rgbMax = max(max(_r, _g), _b);

		FLOAT fDelta = rgbMax - rgbMin;
		FLOAT deltaR;
		FLOAT deltaG;
		FLOAT deltaB;

		FLOAT h = 0.f;
		FLOAT s = 0.f;
		FLOAT l = (FLOAT)((rgbMax + rgbMin) / 2.f);

		if (fDelta != 0.f)
		{
			s = l < .5f ? (FLOAT)(fDelta / (rgbMax + rgbMin)) : (FLOAT)(fDelta / (2.f - rgbMax - rgbMin));
			deltaR = (FLOAT)(((rgbMax - _r) / 6.f + (fDelta / 2.f)) / fDelta);
			deltaG = (FLOAT)(((rgbMax - _g) / 6.f + (fDelta / 2.f)) / fDelta);
			deltaB = (FLOAT)(((rgbMax - _b) / 6.f + (fDelta / 2.f)) / fDelta);

			if (_r == rgbMax)      h = deltaB - deltaG;
			else if (_g == rgbMax) h = (1.f / 3.f) + deltaR - deltaB;
			else if (_b == rgbMax) h = (2.f / 3.f) + deltaG - deltaR;
			if (h < 0.f)           h += 1.f;
			if (h > 1.f)           h -= 1.f;
		}

		hsl.h = h;
		hsl.s = s;
		hsl.l = l;
		return hsl;
	}

	RGBQUAD hsl2rgb(HSL hsl)
	{
		RGBQUAD rgb;

		FLOAT r = hsl.l;
		FLOAT g = hsl.l;
		FLOAT b = hsl.l;

		FLOAT h = hsl.h;
		FLOAT sl = hsl.s;
		FLOAT l = hsl.l;
		FLOAT v = (l <= .5f) ? (l * (1.f + sl)) : (l + sl - l * sl);

		FLOAT m;
		FLOAT sv;
		FLOAT fract;
		FLOAT vsf;
		FLOAT mid1;
		FLOAT mid2;

		INT sextant;

		if (v > 0.f)
		{
			m = l + l - v;
			sv = (v - m) / v;
			h *= 6.f;
			sextant = (INT)h;
			fract = h - sextant;
			vsf = v * sv * fract;
			mid1 = m + vsf;
			mid2 = v - vsf;

			switch (sextant)
			{
			case 0:
				r = v;
				g = mid1;
				b = m;
				break;
			case 1:
				r = mid2;
				g = v;
				b = m;
				break;
			case 2:
				r = m;
				g = v;
				b = mid1;
				break;
			case 3:
				r = m;
				g = mid2;
				b = v;
				break;
			case 4:
				r = mid1;
				g = m;
				b = v;
				break;
			case 5:
				r = v;
				g = m;
				b = mid2;
				break;
			}
		}

		rgb.rgbRed = (BYTE)(r * 255.f);
		rgb.rgbGreen = (BYTE)(g * 255.f);
		rgb.rgbBlue = (BYTE)(b * 255.f);

		return rgb;
	}
}
int stage = 0;
int r = 0, g = 0, b = 0;
COLORREF Hue(int shift) { //credits to Malsteve527 for the NEW hue function (better than GetMBR's)
	switch (stage) {
	case 0:
		r = 255;
		b = 0;
		g < 255 ? g += shift : stage++;
		break;
	case 1:
		g = 255;
		b = 0;
		r > 0 ? r -= shift : stage++;
		break;
	case 2:
		g = 255;
		r = 0;
		b < 255 ? b += shift : stage++;
		break;
	case 3:
		b = 255;
		r = 0;
		g > 0 ? g -= shift : stage++;
		break;
	case 4:
		b = 255;
		g = 0;
		r < 255 ? r += shift : stage++;
		break;
	case 5:
		r = 255;
		g = 0;
		b > 0 ? b -= shift : stage = 0;
		break;
	}

	return RGB(r, g, b);
}


DWORD WINAPI patblt(LPVOID lpParam)
{
	while (1) {
		HDC hdc = GetDC(NULL);
		int w = GetSystemMetrics(SM_CXSCREEN),
			h = GetSystemMetrics(SM_CYSCREEN);

		HBRUSH brush = CreateSolidBrush(RGB(rand() % 255, rand() % 255, rand() % 255));
		SelectObject(hdc, brush);
		PatBlt(hdc, 0, 0, w, h, PATINVERT);
		DeleteObject(brush);
		ReleaseDC(0, hdc);
	}
}

DWORD WINAPI waves1(LPVOID lpParam) //credits to N17Pro3426 for fast sines
{
	HDC hdc = GetDC(NULL);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	HDC hcdc = CreateCompatibleDC(hdc);
	HBITMAP hBitmap = CreateCompatibleBitmap(hdc, w, h);
	SelectObject(hcdc, hBitmap);
	BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
	for (int t = 0; ; t += 20)
	{
		hdc = GetDC(NULL);
		for (int y = 0; y <= h; y++)
		{
			float x = sin((y + t) * (M_PI / 30)) * 25;
			BitBlt(hdc, x, y, w, 1, hcdc, 0, y, SRCCOPY);
		}
		ReleaseDC(NULL, hdc);
		DeleteObject(hdc);
	}
	Sleep(10);
	ReleaseDC(NULL, hcdc);
	DeleteObject(hcdc);
	DeleteObject(hBitmap);
	return 0;
}

DWORD WINAPI smelt(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL);
	int w = GetSystemMetrics(SM_CXSCREEN),
		h = GetSystemMetrics(SM_CYSCREEN),
		rx = rand() % w;
	while (1) {
		hdc = GetDC(NULL);
		w = GetSystemMetrics(SM_CXSCREEN),
		h = GetSystemMetrics(SM_CYSCREEN),
		rx = rand() % w;
		BitBlt(hdc, rx, 10, 100, h, hdc, rx, 0, SRCCOPY);
		ReleaseDC(NULL, hdc);
	}
}
DWORD WINAPI listopad(LPVOID lpvd) //credits to sapphiretech
{
	HDC hdcScreen;
	HICON hApplicationIcon;
	INT w = GetSystemMetrics(SM_CXSCREEN);
	INT h = GetSystemMetrics(SM_CYSCREEN);

	INT directionX = rand() % w;
	INT directionY = rand() % h;
	INT nDirection = (rand() % 4) + 1;

	for (;; )
	{
		hdcScreen = GetDC(HWND_DESKTOP);
		hApplicationIcon = LoadIconW(NULL, IDI_APPLICATION);

		DrawIcon(hdcScreen, directionX, directionY, hApplicationIcon);

		if (directionX >= w)
		{
			directionX = 0;
		}

		if (directionX < 0)
		{
			directionX = w - 1;
		}

		if (directionY >= h)
		{
			directionY = 0;
		}

		if (directionY < 0)
		{
			directionY = h - 1;
		}

		// Switch icon direction
		// TODO: add random icon spammer
		// appearing randomly in this payload
		switch (nDirection)
		{
		case 1: directionX += 5; break;
		case 2: directionX -= 5; break;

		case 3: directionY += 5; break;
		case 4: directionY -= 5; break;
		}
		if ((rand() % 100) < 5)
		{
			nDirection = (rand() % 4) + 1;
		}

		ReleaseDC(NULL, hdcScreen);
		DeleteDC(hdcScreen);
		//Sleep(10);
	}
}

DWORD WINAPI payload1(LPVOID lpParam) {
	HDC hdc = GetDC(0);
	HDC hdcCopy = CreateCompatibleDC(hdc);

	BITMAPINFO bmpi = { 0 };

	int sw = GetSystemMetrics(0);
	int sh = GetSystemMetrics(1);

	float radius = 0.f;
	double angle = 0;

	while (1) {
		HDC hdc = GetDC(0);

		float x = (cos(angle)) * radius;
		float y = (sin(angle)) * radius;

		HBRUSH brush = CreateSolidBrush(RGB(rand() % 255, rand() % 255, rand() % 255));
		SelectObject(hdc, brush);

		BitBlt(hdc, 0, 0, sw, sh, hdc, x, y, PATINVERT);
		StretchBlt(hdc, x, y, sw - x * 2, sh - y * 2, hdc, 0, 0, sw, sh, SRCCOPY);
		radius += 0.1f;

		DeleteObject(brush);
		ReleaseDC(0, hdc);

		angle = fmod(angle + M_PI / radius, M_PI * radius) / 1.001;
	}
}

DWORD WINAPI textout1(LPVOID lpvd)
{
	int x = GetSystemMetrics(0); int y = GetSystemMetrics(1);
	LPCSTR text1 = 0;
	LPCSTR text2 = 0;
	LPCSTR text3 = 0;
	LPCSTR text4 = 0;
	LPCSTR text5 = 0;
	LPCSTR text6 = 0;
	while (1)
	{
		HDC hdc = GetDC(0);
		SetBkMode(hdc, 0);
		text1 = "Pentacyanocyclopentadiene.exe";
		text2 = "pankoza";
		text3 = "UltraDasher965";
		text4 = "zabwpk ovl";
		text5 = "loser";
		text6 = "better luck next time lmao";
		SetTextColor(hdc, Hue(3));
		HFONT font = CreateFontA(rand() % 100, rand() % 100, rand() % 3600, 0, FW_EXTRALIGHT, 0, 0, 0, ANSI_CHARSET, 0, 0, 0, 0, "System");
		SelectObject(hdc, font);
		TextOutA(hdc, rand() % x, rand() % y, text1, strlen(text1));
		TextOutA(hdc, rand() % x, rand() % y, text2, strlen(text2));
		TextOutA(hdc, rand() % x, rand() % y, text3, strlen(text3));
		TextOutA(hdc, rand() % x, rand() % y, text4, strlen(text4));
		TextOutA(hdc, rand() % x, rand() % y, text5, strlen(text5));
		TextOutA(hdc, rand() % x, rand() % y, text6, strlen(text6));
		DeleteObject(font);
		ReleaseDC(0, hdc);
		Sleep(10);
	}
}

DWORD WINAPI redraw(LPVOID lpParam) {
	while (1) {
		RedrawWindow(0, 0, 0, 133);
		Sleep(rand() % 1000);
	}
}

DWORD WINAPI icon(LPVOID lpParam) {
	HDC hdcScreen;
	HICON hApplicationIcon;
	INT w = GetSystemMetrics(SM_CXSCREEN);
	INT h = GetSystemMetrics(SM_CYSCREEN);

	INT directionX = rand() % w;
	INT directionY = rand() % h;
	INT nDirection = (rand() % 4) + 1;

	for (;; )
	{
		hdcScreen = GetDC(HWND_DESKTOP);
		HINSTANCE lib = LoadLibraryA("moricons.dll");
		hApplicationIcon = LoadIcon(lib, MAKEINTRESOURCE(rand() % 113));

		DrawIcon(hdcScreen, directionX, directionY, hApplicationIcon);

		if (directionX >= w)
		{
			directionX = 0;
		}

		if (directionX < 0)
		{
			directionX = w - 1;
		}

		if (directionY >= h)
		{
			directionY = 0;
		}

		if (directionY < 0)
		{
			directionY = h - 1;
		}

		switch (nDirection)
		{
		case 1: directionX += 5; break;
		case 2: directionX -= 5; break;

		case 3: directionY += 5; break;
		case 4: directionY -= 5; break;
		}
		if ((rand() % 100) < 5)
		{
			nDirection = (rand() % 4) + 1;
		}

		Sleep(1);
		ReleaseDC(NULL, hdcScreen);
		DeleteDC(hdcScreen);
	}
}

VOID WINAPI ci(int x, int y, int w, int h)
{
	HDC hdc = GetDC(0);
	HRGN hrgn = CreateRoundRectRgn(x, y, w + x, h + y, 10, 10);
	SelectClipRgn(hdc, hrgn);
	HBRUSH brush = CreateSolidBrush(RGB(rand() % 255, rand() % 255, rand() % 255));
	SelectObject(hdc, brush);
	BitBlt(hdc, x, y, w, h, hdc, x, y, PATINVERT);
	DeleteObject(hrgn);
	DeleteObject(brush);
	ReleaseDC(NULL, hdc);
}

DWORD WINAPI wef(LPVOID lpParam) {
	RECT rect;
	GetWindowRect(GetDesktopWindow(), &rect);
	int w = rect.right - rect.left, h = rect.bottom - rect.top;

	for (int t = 0;; t++)
	{
		const int size = rand() % 300;
		int x = rand() % (w + size) - size / 2, y = rand() % (h + size) - size / 2;

		for (int i = 0; i < size; i += 10)
		{
			ci(x - i / 2, y - i / 2, i, i);
			Sleep(1);
		}
	}
}

DWORD WINAPI shader1(LPVOID lpvd) //credits to fr4ctalz, but I modified it
{
	HDC hdc = GetDC(NULL);
	HDC hdcCopy = CreateCompatibleDC(hdc);
	int screenWidth = GetSystemMetrics(SM_CXSCREEN);
	int screenHeight = GetSystemMetrics(SM_CYSCREEN);
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;

	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = screenWidth;
	bmpi.bmiHeader.biHeight = screenHeight;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;


	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;

	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);

	INT i = 0;

	while (1)
	{
		hdc = GetDC(NULL);
		StretchBlt(hdcCopy, 0, 0, screenWidth, screenHeight, hdc, 0, 0, screenWidth, screenHeight, SRCCOPY);

		RGBQUAD rgbquadCopy;

		for (int x = 0; x < screenWidth; x++)
		{
			for (int y = 0; y < screenHeight; y++)
			{
				int index = y * screenWidth + x;

				int fx = (int)((i ^ 4) + (i * 4) * sqrt(x ^ y ^ i ^ 7 | x + y));

				rgbquadCopy = rgbquad[index];

				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = fmod(fx / 400.f + y / screenHeight * .2f, 1.f);

				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}

		i++;

		StretchBlt(hdc, 0, 0, screenWidth, screenHeight, hdcCopy, 0, 0, screenWidth, screenHeight, SRCCOPY);
		ReleaseDC(NULL, hdc);
		DeleteDC(hdc);
	}

	return 0x00;
}

float fade(float t) {
	return t * t * t * (t * (t * 6 - 15) + 1000);
}

float lerp(float a, float b, float t) {
	return a + t * (b - a);
}

float grad(int hash, float x) {
	return (hash & 1) ? x : -x;
}

float noise1D(float x) {
	int x0 = (int)floor(x) & 2550;
	int x1 = (x0 + 1) & 2550;

	float xf = x - floor(x);
	float u = fade(xf);

	static int p[2048];
	static bool initialized = false;

	if (!initialized) {
		for (int i = 0; i < 1024; i++) {
			p[i] = p[i + 1024] = rand() % 1024;
		}
		initialized = true;
	}

	float g0 = grad(p[x0], xf);
	float g1 = grad(p[x1], xf - 1.0f);

	return lerp(g0, g1, u);
}

DWORD WINAPI payload2(LPVOID lpParam) {
	HDC hDesk = GetDC(NULL);

	int w = GetSystemMetrics(SM_CXSCREEN);
	int h = GetSystemMetrics(SM_CYSCREEN);

	HDC hMemDC = CreateCompatibleDC(hDesk);
	HBITMAP hBmp = CreateCompatibleBitmap(hDesk, w, h);
	HBITMAP hOldBmp = (HBITMAP)SelectObject(hMemDC, hBmp);

	double angle = 0;
	float amplitude = 0.0f;

	BLENDFUNCTION blend;

	blend.BlendOp = AC_SRC_OVER;
	blend.BlendFlags = 0;
	blend.SourceConstantAlpha = 220;
	blend.AlphaFormat = 0;

	while (true) {
		for (int i = 0; i < w; i++) {
			int offset = (int)(amplitude * noise1D(i * 0.001f + angle * 0.5f));
			int offset2 = (int)(amplitude * noise1D(i * 0.003f + angle * 0.05f));

			BitBlt(hMemDC, i, 0, 1, h, hDesk, i, offset, SRCAND);
			BitBlt(hMemDC, i, 0, 1, h, hDesk, i, offset2, SRCPAINT);
		}

		AlphaBlend(hDesk, 0, 0, w, h, hMemDC, 0, 0, w, h, blend);

		angle += 1.f;
		amplitude += 0.01f;
	}

	SelectObject(hMemDC, hOldBmp);
	DeleteObject(hBmp);
	DeleteDC(hMemDC);
	ReleaseDC(NULL, hDesk);

	return 0;
}

DWORD WINAPI payload3(LPVOID lpParam) {
	HDC hdc = GetDC(NULL);
	HDC hdcCopy = CreateCompatibleDC(hdc);

	int w = GetSystemMetrics(0);
	int h = GetSystemMetrics(1);

	HBITMAP bmp = CreateCompatibleBitmap(hdc, w, h);
	SelectObject(hdcCopy, bmp);

	BLENDFUNCTION blur = { 0 };

	blur.BlendOp = AC_SRC_OVER;
	blur.BlendFlags = 0;
	blur.AlphaFormat = 0;
	blur.SourceConstantAlpha = 50;

	int a = 0;
	int b = 0;
	int c = 0;
	while (1) {
		hdc = GetDC(NULL);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, b, c, NOTSRCCOPY);
		AlphaBlend(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, blur);
		a += 1;
		b = sin(a / 21.f) * 50;
		c = cos(a / 20.f) * 50;
		ReleaseDC(0, hdc);
	}
}

DWORD WINAPI cubes(LPVOID lpParam) {
	while (1) {
		HDC hdc = GetDC(0);
		int w = GetSystemMetrics(0);
		int h = GetSystemMetrics(1);
		int size = 100 + rand() % 100;
		HBRUSH brush = CreateSolidBrush(RGB(rand() % 255, rand() % 255, rand() % 255));
		SelectObject(hdc, brush);
		BitBlt(hdc, rand() % w, rand() % h, size, size, hdc, rand() % w, rand() % h, PATINVERT);
		DeleteObject(brush);
		Sleep(1);
		ReleaseDC(0, hdc);
	}
}

DWORD WINAPI shader2(LPVOID lpParam) {
	HDC hdc = GetDC(NULL);
	HDC hdcCopy = CreateCompatibleDC(hdc);
	int screenWidth = GetSystemMetrics(SM_CXSCREEN);
	int screenHeight = GetSystemMetrics(SM_CYSCREEN);
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;

	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = screenWidth;
	bmpi.bmiHeader.biHeight = screenHeight;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;


	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;

	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);

	INT i = 0;

	while (1)
	{
		hdc = GetDC(NULL);
		StretchBlt(hdcCopy, 0, 0, screenWidth, screenHeight, hdc, 0, 0, screenWidth, screenHeight, SRCCOPY);

		RGBQUAD rgbquadCopy;

		for (int x = 0; x < screenWidth; x++)
		{
			for (int y = 0; y < screenHeight; y++)
			{
				int index = y * screenWidth + x;

				int cx = x - (screenWidth / 2);
				int cy = y - (screenHeight / 2);

				int fx = i * (cbrt((cx * cx) + (cy * cy)));

				rgbquadCopy = rgbquad[index];

				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = fmod(fx / 400.f + y / screenHeight * .2f, 1.f);
				hslcolor.s = fmod(fx / 110.f + y / screenHeight * .2f, 1.f);
				hslcolor.l += 0.01;

				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}

		i++;

		StretchBlt(hdc, 0, 0, screenWidth, screenHeight, hdcCopy, 0, 0, screenWidth, screenHeight, SRCCOPY);
		ReleaseDC(NULL, hdc);
		DeleteDC(hdc);
	}
}

DWORD WINAPI shader3(LPVOID lpParam) {
	HDC hdc = GetDC(NULL);
	HDC hdcCopy = CreateCompatibleDC(hdc);
	int screenWidth = GetSystemMetrics(SM_CXSCREEN);
	int screenHeight = GetSystemMetrics(SM_CYSCREEN);
	int w = GetSystemMetrics(SM_CXSCREEN);
	int h = GetSystemMetrics(SM_CYSCREEN);
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;

	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = screenWidth;
	bmpi.bmiHeader.biHeight = screenHeight;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;


	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;

	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);

	INT i = 0;
	int o = 0;

	RECT rect;
	while (1)
	{
		hdc = GetDC(NULL);
		StretchBlt(hdcCopy, 0, 0, screenWidth, screenHeight, hdc, 0, 0, screenWidth, screenHeight, SRCCOPY);

		RGBQUAD rgbquadCopy;

		for (int x = 0; x < screenWidth; x++)
		{
			for (int y = 0; y < screenHeight; y++)
			{
				int index = y * screenWidth + x;

				int fx = (i * (x % ((1 + i) + y))) + (x ^ y);
				int sat = (i * 20) * (x ^ y);
				int light = ((y + tan(x / (1 + (i * 3)))) * (1 + (i / 5.f))) + (1 + ((x + sin(y / 100.f)) * 2));

				rgbquadCopy = rgbquad[index];

				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = fmod(fx / 1000.f + y / screenHeight * .2f, 1.f);
				hslcolor.s += 0.1f;
				hslcolor.l = fmod(light / 3000.f + y / screenHeight * .2f, 1.f);

				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}

		i++;

		POINT lpPoint[3];
		hdc = GetDC(0);
		GetWindowRect(GetDesktopWindow(), &rect);

		lpPoint[0].x = rect.left - o;
		lpPoint[0].y = rect.top + o;
		lpPoint[1].x = rect.right + o;
		lpPoint[1].y = rect.top + o;
		lpPoint[2].x = rect.left - o;
		lpPoint[2].y = rect.bottom;
		o += 3;

		StretchBlt(hdc, 0, 0, screenWidth, screenHeight, hdcCopy, 0, 0, screenWidth, screenHeight, SRCCOPY);
		PlgBlt(hdc, lpPoint, hdc, rect.left - 20, rect.top + 20, rect.right - rect.left, rect.bottom - rect.top, 0, 0, 0);
		ReleaseDC(NULL, hdc);
		DeleteDC(hdc);
	}
}
DWORD WINAPI shader4(LPVOID lpvd) { //credits to simpleemarie
	HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
	INT w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	BITMAPINFO bmi = { 0 };
	PRGBQUAD rgbScreen = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = h;
	HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcMem, hbmTemp);

	for (;;) {
		hdcScreen = GetDC(0);
		BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);
		for (INT i = 0; i < w * h; i++) {
			INT x = i % w, y = i / w;
			int average = round((float)(rgbScreen[i].b + rgbScreen[i].r + rgbScreen[i].g) / 10);
			rgbScreen[i].r = average + x;
			rgbScreen[i].r = average + y;
			rgbScreen[i].b = average + x;
			rgbScreen[i].rgb -= x;
		}
		BitBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
		ReleaseDC(NULL, hdcScreen); DeleteDC(hdcScreen);
	}
	Sleep(10);
}

DWORD WINAPI waves2(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	HDC hcdc = CreateCompatibleDC(hdc);
	HBITMAP hBitmap = CreateCompatibleBitmap(hdc, w, h);
	SelectObject(hcdc, hBitmap);
	BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
	for (int t = 0; ; t += 20)
	{
		hdc = GetDC(NULL);
		for (int y = 0; y <= h; y++)
		{
			float x = cos((y + t) * (M_PI / 30)) * 25;
			BitBlt(hdc, x, y, w, 1, hcdc, 0, y, SRCCOPY);
		}
		ReleaseDC(NULL, hdc);
		DeleteObject(hdc);
	}
	Sleep(10);
	ReleaseDC(NULL, hcdc);
	DeleteObject(hcdc);
	DeleteObject(hBitmap);
	return 0;
}


void sound1(int hz, int secs) {
	const int sample_rate = hz;
	const int channels = 1;
	const int bits_per_sample = 8;
	const int data_size = sample_rate * secs;

	BYTE* data = new BYTE[data_size];
	for (int t = 2; t < data_size; ++t) {
		data[t] = static_cast<BYTE>(
			(t >> 4) * (t ^ t >> 5)
			);
	}

	uint32_t total_size = 44 + data_size;
	BYTE* wav = new BYTE[total_size];
	BYTE* ptr = wav;

	auto write = [&](const void* src, size_t size) {
		memcpy(ptr, src, size);
		ptr += size;
		};

	write("RIFF", 4);
	uint32_t chunk_size = total_size - 8;
	write(&chunk_size, 4);
	write("WAVE", 4);

	write("fmt ", 4);
	uint32_t subchunk1_size = 16;
	write(&subchunk1_size, 4);
	uint16_t audio_format = 1;
	write(&audio_format, 2);
	uint16_t num_channels = channels;
	write(&num_channels, 2);
	uint32_t sample_rate_dw = sample_rate;
	write(&sample_rate_dw, 4);
	uint32_t byte_rate = sample_rate * channels * bits_per_sample / 8;
	write(&byte_rate, 4);
	uint16_t block_align = channels * bits_per_sample / 8;
	write(&block_align, 2);
	uint16_t bits_per_sample_w = bits_per_sample;
	write(&bits_per_sample_w, 2);

	write("data", 4);
	uint32_t subchunk2_size = data_size;
	write(&subchunk2_size, 4);
	write(data, data_size);

	PlaySoundA(reinterpret_cast<LPCSTR>(wav), NULL, SND_MEMORY | SND_SYNC);

	delete[] data;
	delete[] wav;
}
void sound2(int hz, int secs) {
	const int sample_rate = hz;
	const int channels = 1;
	const int bits_per_sample = 8;
	const int data_size = sample_rate * secs;

	BYTE* data = new BYTE[data_size];
	for (int t = 2; t < data_size; ++t) {
		data[t] = static_cast<BYTE>(
			((((t*(t>>5&t>>6))>>(7&t>>13))*100)-t)
			);
	}

	uint32_t total_size = 44 + data_size;
	BYTE* wav = new BYTE[total_size];
	BYTE* ptr = wav;

	auto write = [&](const void* src, size_t size) {
		memcpy(ptr, src, size);
		ptr += size;
		};

	write("RIFF", 4);
	uint32_t chunk_size = total_size - 8;
	write(&chunk_size, 4);
	write("WAVE", 4);

	write("fmt ", 4);
	uint32_t subchunk1_size = 16;
	write(&subchunk1_size, 4);
	uint16_t audio_format = 1;
	write(&audio_format, 2);
	uint16_t num_channels = channels;
	write(&num_channels, 2);
	uint32_t sample_rate_dw = sample_rate;
	write(&sample_rate_dw, 4);
	uint32_t byte_rate = sample_rate * channels * bits_per_sample / 8;
	write(&byte_rate, 4);
	uint16_t block_align = channels * bits_per_sample / 8;
	write(&block_align, 2);
	uint16_t bits_per_sample_w = bits_per_sample;
	write(&bits_per_sample_w, 2);

	write("data", 4);
	uint32_t subchunk2_size = data_size;
	write(&subchunk2_size, 4);
	write(data, data_size);

	PlaySoundA(reinterpret_cast<LPCSTR>(wav), NULL, SND_MEMORY | SND_SYNC);

	delete[] data;
	delete[] wav;
}

void sound3(int hz, int secs) {
	const int sample_rate = hz;
	const int channels = 1;
	const int bits_per_sample = 8;
	const int data_size = sample_rate * secs;

	BYTE* data = new BYTE[data_size];
	for (int t = 2; t < data_size; ++t) {
		data[t] = static_cast<BYTE>(
			(((t * (t >> 5 | t >> 6)) >> (7 & t >> 5)) * 10) ^ t
			);
	}

	uint32_t total_size = 44 + data_size;
	BYTE* wav = new BYTE[total_size];
	BYTE* ptr = wav;

	auto write = [&](const void* src, size_t size) {
		memcpy(ptr, src, size);
		ptr += size;
		};

	write("RIFF", 4);
	uint32_t chunk_size = total_size - 8;
	write(&chunk_size, 4);
	write("WAVE", 4);

	write("fmt ", 4);
	uint32_t subchunk1_size = 16;
	write(&subchunk1_size, 4);
	uint16_t audio_format = 1;
	write(&audio_format, 2);
	uint16_t num_channels = channels;
	write(&num_channels, 2);
	uint32_t sample_rate_dw = sample_rate;
	write(&sample_rate_dw, 4);
	uint32_t byte_rate = sample_rate * channels * bits_per_sample / 8;
	write(&byte_rate, 4);
	uint16_t block_align = channels * bits_per_sample / 8;
	write(&block_align, 2);
	uint16_t bits_per_sample_w = bits_per_sample;
	write(&bits_per_sample_w, 2);

	write("data", 4);
	uint32_t subchunk2_size = data_size;
	write(&subchunk2_size, 4);
	write(data, data_size);

	PlaySoundA(reinterpret_cast<LPCSTR>(wav), NULL, SND_MEMORY | SND_SYNC);

	delete[] data;
	delete[] wav;
}

void sound4(int hz, int secs) {
	const int sample_rate = hz;
	const int channels = 1;
	const int bits_per_sample = 8;
	const int data_size = sample_rate * secs;

	BYTE* data = new BYTE[data_size];
	for (int t = 2; t < data_size; ++t) {
		data[t] = static_cast<BYTE>(
			((((t / 8 | 0) ^ (t / 8 | 0) - 1280) % 11 * t / 2 & 127) + (((t / 512 | 0) ^ (t / 500 | 0) - 2) % 13 * t / 2 & 127)) * 5
			);
	}

	uint32_t total_size = 44 + data_size;
	BYTE* wav = new BYTE[total_size];
	BYTE* ptr = wav;

	auto write = [&](const void* src, size_t size) {
		memcpy(ptr, src, size);
		ptr += size;
		};

	write("RIFF", 4);
	uint32_t chunk_size = total_size - 8;
	write(&chunk_size, 4);
	write("WAVE", 4);

	write("fmt ", 4);
	uint32_t subchunk1_size = 16;
	write(&subchunk1_size, 4);
	uint16_t audio_format = 1;
	write(&audio_format, 2);
	uint16_t num_channels = channels;
	write(&num_channels, 2);
	uint32_t sample_rate_dw = sample_rate;
	write(&sample_rate_dw, 4);
	uint32_t byte_rate = sample_rate * channels * bits_per_sample / 8;
	write(&byte_rate, 4);
	uint16_t block_align = channels * bits_per_sample / 8;
	write(&block_align, 2);
	uint16_t bits_per_sample_w = bits_per_sample;
	write(&bits_per_sample_w, 2);

	write("data", 4);
	uint32_t subchunk2_size = data_size;
	write(&subchunk2_size, 4);
	write(data, data_size);

	PlaySoundA(reinterpret_cast<LPCSTR>(wav), NULL, SND_MEMORY | SND_SYNC);

	delete[] data;
	delete[] wav;
}
void sound5(int hz, int secs) {
	const int sample_rate = hz;
	const int channels = 1;
	const int bits_per_sample = 8;
	const int data_size = sample_rate * secs;

	BYTE* data = new BYTE[data_size];
	for (int t = 2; t < data_size; ++t) {
		data[t] = static_cast<BYTE>(
			(((t & (t >> 7) - t & t >> 8) * t))
			);
	}

	uint32_t total_size = 44 + data_size;
	BYTE* wav = new BYTE[total_size];
	BYTE* ptr = wav;

	auto write = [&](const void* src, size_t size) {
		memcpy(ptr, src, size);
		ptr += size;
		};

	write("RIFF", 4);
	uint32_t chunk_size = total_size - 8;
	write(&chunk_size, 4);
	write("WAVE", 4);

	write("fmt ", 4);
	uint32_t subchunk1_size = 16;
	write(&subchunk1_size, 4);
	uint16_t audio_format = 1;
	write(&audio_format, 2);
	uint16_t num_channels = channels;
	write(&num_channels, 2);
	uint32_t sample_rate_dw = sample_rate;
	write(&sample_rate_dw, 4);
	uint32_t byte_rate = sample_rate * channels * bits_per_sample / 8;
	write(&byte_rate, 4);
	uint16_t block_align = channels * bits_per_sample / 8;
	write(&block_align, 2);
	uint16_t bits_per_sample_w = bits_per_sample;
	write(&bits_per_sample_w, 2);

	write("data", 4);
	uint32_t subchunk2_size = data_size;
	write(&subchunk2_size, 4);
	write(data, data_size);

	PlaySoundA(reinterpret_cast<LPCSTR>(wav), NULL, SND_MEMORY | SND_SYNC);

	delete[] data;
	delete[] wav;
}

void sound6(int hz, int secs) {
	const int sample_rate = hz;
	const int channels = 1;
	const int bits_per_sample = 8;
	const int data_size = sample_rate * secs;

	BYTE* data = new BYTE[data_size];
	for (int t = 2; t < data_size; ++t) {
		data[t] = static_cast<BYTE>(
			(((t & (t >> 7) - t & t >> 8) * t))
			);
	}

	uint32_t total_size = 44 + data_size;
	BYTE* wav = new BYTE[total_size];
	BYTE* ptr = wav;

	auto write = [&](const void* src, size_t size) {
		memcpy(ptr, src, size);
		ptr += size;
		};

	write("RIFF", 4);
	uint32_t chunk_size = total_size - 8;
	write(&chunk_size, 4);
	write("WAVE", 4);

	write("fmt ", 4);
	uint32_t subchunk1_size = 16;
	write(&subchunk1_size, 4);
	uint16_t audio_format = 1;
	write(&audio_format, 2);
	uint16_t num_channels = channels;
	write(&num_channels, 2);
	uint32_t sample_rate_dw = sample_rate;
	write(&sample_rate_dw, 4);
	uint32_t byte_rate = sample_rate * channels * bits_per_sample / 8;
	write(&byte_rate, 4);
	uint16_t block_align = channels * bits_per_sample / 8;
	write(&block_align, 2);
	uint16_t bits_per_sample_w = bits_per_sample;
	write(&bits_per_sample_w, 2);

	write("data", 4);
	uint32_t subchunk2_size = data_size;
	write(&subchunk2_size, 4);
	write(data, data_size);

	PlaySoundA(reinterpret_cast<LPCSTR>(wav), NULL, SND_MEMORY | SND_SYNC);

	delete[] data;
	delete[] wav;
}
void sound7(int hz, int secs) {
	const int sample_rate = hz;
	const int channels = 1;
	const int bits_per_sample = 8;
	const int data_size = sample_rate * secs;

	BYTE* data = new BYTE[data_size];
	for (int t = 2; t < data_size; ++t) {
		data[t] = static_cast<BYTE>(
			((((2 * t & (t & 256 ? -t : t) >> 8 & (t & 256 ? -t : t) >> 6)) * 10) + (t >> 1)) & 128
			);
	}

	uint32_t total_size = 44 + data_size;
	BYTE* wav = new BYTE[total_size];
	BYTE* ptr = wav;

	auto write = [&](const void* src, size_t size) {
		memcpy(ptr, src, size);
		ptr += size;
		};

	write("RIFF", 4);
	uint32_t chunk_size = total_size - 8;
	write(&chunk_size, 4);
	write("WAVE", 4);

	write("fmt ", 4);
	uint32_t subchunk1_size = 16;
	write(&subchunk1_size, 4);
	uint16_t audio_format = 1;
	write(&audio_format, 2);
	uint16_t num_channels = channels;
	write(&num_channels, 2);
	uint32_t sample_rate_dw = sample_rate;
	write(&sample_rate_dw, 4);
	uint32_t byte_rate = sample_rate * channels * bits_per_sample / 8;
	write(&byte_rate, 4);
	uint16_t block_align = channels * bits_per_sample / 8;
	write(&block_align, 2);
	uint16_t bits_per_sample_w = bits_per_sample;
	write(&bits_per_sample_w, 2);

	write("data", 4);
	uint32_t subchunk2_size = data_size;
	write(&subchunk2_size, 4);
	write(data, data_size);

	PlaySoundA(reinterpret_cast<LPCSTR>(wav), NULL, SND_MEMORY | SND_SYNC);

	delete[] data;
	delete[] wav;
}

void sound8(int hz, int secs) {
	const int sample_rate = hz;
	const int channels = 1;
	const int bits_per_sample = 8;
	const int data_size = sample_rate * secs;

	BYTE* data = new BYTE[data_size];
	for (int t = 2; t < data_size; ++t) {
		data[t] = static_cast<BYTE>(
			((((2 * t % 2556) / (1 + (t >> 10 & (t / (1 + (t / 16 & 8192 ? 2 : 4)) & 16 ? 31 : 120)))) * t) >> 5)
			);
	}

	uint32_t total_size = 44 + data_size;
	BYTE* wav = new BYTE[total_size];
	BYTE* ptr = wav;

	auto write = [&](const void* src, size_t size) {
		memcpy(ptr, src, size);
		ptr += size;
		};

	write("RIFF", 4);
	uint32_t chunk_size = total_size - 8;
	write(&chunk_size, 4);
	write("WAVE", 4);

	write("fmt ", 4);
	uint32_t subchunk1_size = 16;
	write(&subchunk1_size, 4);
	uint16_t audio_format = 1;
	write(&audio_format, 2);
	uint16_t num_channels = channels;
	write(&num_channels, 2);
	uint32_t sample_rate_dw = sample_rate;
	write(&sample_rate_dw, 4);
	uint32_t byte_rate = sample_rate * channels * bits_per_sample / 8;
	write(&byte_rate, 4);
	uint16_t block_align = channels * bits_per_sample / 8;
	write(&block_align, 2);
	uint16_t bits_per_sample_w = bits_per_sample;
	write(&bits_per_sample_w, 2);

	write("data", 4);
	uint32_t subchunk2_size = data_size;
	write(&subchunk2_size, 4);
	write(data, data_size);

	PlaySoundA(reinterpret_cast<LPCSTR>(wav), NULL, SND_MEMORY | SND_SYNC);

	delete[] data;
	delete[] wav;
}
void sound9(int hz, int secs) {
	const int sample_rate = hz;
	const int channels = 1;
	const int bits_per_sample = 8;
	const int data_size = sample_rate * secs;

	BYTE* data = new BYTE[data_size];
	for (int t = 2; t < data_size; ++t) {
		data[t] = static_cast<BYTE>(
			(t * (66 ^ t >> 67))
			);
	}

	uint32_t total_size = 44 + data_size;
	BYTE* wav = new BYTE[total_size];
	BYTE* ptr = wav;

	auto write = [&](const void* src, size_t size) {
		memcpy(ptr, src, size);
		ptr += size;
		};

	write("RIFF", 4);
	uint32_t chunk_size = total_size - 8;
	write(&chunk_size, 4);
	write("WAVE", 4);

	write("fmt ", 4);
	uint32_t subchunk1_size = 16;
	write(&subchunk1_size, 4);
	uint16_t audio_format = 1;
	write(&audio_format, 2);
	uint16_t num_channels = channels;
	write(&num_channels, 2);
	uint32_t sample_rate_dw = sample_rate;
	write(&sample_rate_dw, 4);
	uint32_t byte_rate = sample_rate * channels * bits_per_sample / 8;
	write(&byte_rate, 4);
	uint16_t block_align = channels * bits_per_sample / 8;
	write(&block_align, 2);
	uint16_t bits_per_sample_w = bits_per_sample;
	write(&bits_per_sample_w, 2);

	write("data", 4);
	uint32_t subchunk2_size = data_size;
	write(&subchunk2_size, 4);
	write(data, data_size);

	PlaySoundA(reinterpret_cast<LPCSTR>(wav), NULL, SND_MEMORY | SND_SYNC);

	delete[] data;
	delete[] wav;
}
void sound10(int hz, int secs) {
	const int sample_rate = hz;
	const int channels = 1;
	const int bits_per_sample = 8;
	const int data_size = sample_rate * secs;

	BYTE* data = new BYTE[data_size];
	for (int t = 2; t < data_size; ++t) {
		data[t] = static_cast<BYTE>(
			(t * (61 ^ t >> 5))
			);
	}

	uint32_t total_size = 44 + data_size;
	BYTE* wav = new BYTE[total_size];
	BYTE* ptr = wav;

	auto write = [&](const void* src, size_t size) {
		memcpy(ptr, src, size);
		ptr += size;
		};

	write("RIFF", 4);
	uint32_t chunk_size = total_size - 8;
	write(&chunk_size, 4);
	write("WAVE", 4);

	write("fmt ", 4);
	uint32_t subchunk1_size = 16;
	write(&subchunk1_size, 4);
	uint16_t audio_format = 1;
	write(&audio_format, 2);
	uint16_t num_channels = channels;
	write(&num_channels, 2);
	uint32_t sample_rate_dw = sample_rate;
	write(&sample_rate_dw, 4);
	uint32_t byte_rate = sample_rate * channels * bits_per_sample / 8;
	write(&byte_rate, 4);
	uint16_t block_align = channels * bits_per_sample / 8;
	write(&block_align, 2);
	uint16_t bits_per_sample_w = bits_per_sample;
	write(&bits_per_sample_w, 2);

	write("data", 4);
	uint32_t subchunk2_size = data_size;
	write(&subchunk2_size, 4);
	write(data, data_size);

	PlaySoundA(reinterpret_cast<LPCSTR>(wav), NULL, SND_MEMORY | SND_SYNC);

	delete[] data;
	delete[] wav;
}
void sound11(int hz, int secs) {
	const int sample_rate = hz;
	const int channels = 1;
	const int bits_per_sample = 8;
	const int data_size = sample_rate * secs;

	BYTE* data = new BYTE[data_size];
	for (int t = 2; t < data_size; ++t) {
		data[t] = static_cast<BYTE>(
			t * (31 * t >> 4)
			);
	}

	uint32_t total_size = 44 + data_size;
	BYTE* wav = new BYTE[total_size];
	BYTE* ptr = wav;

	auto write = [&](const void* src, size_t size) {
		memcpy(ptr, src, size);
		ptr += size;
		};

	write("RIFF", 4);
	uint32_t chunk_size = total_size - 8;
	write(&chunk_size, 4);
	write("WAVE", 4);

	write("fmt ", 4);
	uint32_t subchunk1_size = 16;
	write(&subchunk1_size, 4);
	uint16_t audio_format = 1;
	write(&audio_format, 2);
	uint16_t num_channels = channels;
	write(&num_channels, 2);
	uint32_t sample_rate_dw = sample_rate;
	write(&sample_rate_dw, 4);
	uint32_t byte_rate = sample_rate * channels * bits_per_sample / 8;
	write(&byte_rate, 4);
	uint16_t block_align = channels * bits_per_sample / 8;
	write(&block_align, 2);
	uint16_t bits_per_sample_w = bits_per_sample;
	write(&bits_per_sample_w, 2);

	write("data", 4);
	uint32_t subchunk2_size = data_size;
	write(&subchunk2_size, 4);
	write(data, data_size);

	PlaySoundA(reinterpret_cast<LPCSTR>(wav), NULL, SND_MEMORY | SND_SYNC);

	delete[] data;
	delete[] wav;
}

void sound12(int hz, int secs) {
	const int sample_rate = hz;
	const int channels = 1;
	const int bits_per_sample = 8;
	const int data_size = sample_rate * secs;

	BYTE* data = new BYTE[data_size];
	for (int t = 2; t < data_size; ++t) {
		data[t] = static_cast<BYTE>(
			t * (31 * t >> 2)
			);
	}

	uint32_t total_size = 44 + data_size;
	BYTE* wav = new BYTE[total_size];
	BYTE* ptr = wav;

	auto write = [&](const void* src, size_t size) {
		memcpy(ptr, src, size);
		ptr += size;
		};

	write("RIFF", 4);
	uint32_t chunk_size = total_size - 8;
	write(&chunk_size, 4);
	write("WAVE", 4);

	write("fmt ", 4);
	uint32_t subchunk1_size = 16;
	write(&subchunk1_size, 4);
	uint16_t audio_format = 1;
	write(&audio_format, 2);
	uint16_t num_channels = channels;
	write(&num_channels, 2);
	uint32_t sample_rate_dw = sample_rate;
	write(&sample_rate_dw, 4);
	uint32_t byte_rate = sample_rate * channels * bits_per_sample / 8;
	write(&byte_rate, 4);
	uint16_t block_align = channels * bits_per_sample / 8;
	write(&block_align, 2);
	uint16_t bits_per_sample_w = bits_per_sample;
	write(&bits_per_sample_w, 2);

	write("data", 4);
	uint32_t subchunk2_size = data_size;
	write(&subchunk2_size, 4);
	write(data, data_size);

	PlaySoundA(reinterpret_cast<LPCSTR>(wav), NULL, SND_MEMORY | SND_SYNC);

	delete[] data;
	delete[] wav;
}


DWORD WINAPI fakeerror(LPVOID lpParam) {
	MessageBox(NULL, L"This operation has been cancelled due to restrictions in effect on this computer. Please contact your system administrator.", L"Restrictions", MB_ICONERROR);
	return 0;
}

int CALLBACK WinMain(
	HINSTANCE hInstance, HINSTANCE hPrevInstance,
	LPSTR     lpCmdLine, int       nCmdShow
)
{
	if (MessageBoxW(NULL, L"Run GDI Only?\nWarning!\nThis contains strong language, loud noises and flashing colors. The creator is not responsible.", L"pentacyanocyclopentadiene.exe by pankoza and UltraDasher965 (GDI Only)", MB_YESNO | MB_ICONEXCLAMATION) == IDNO)
	{
		ExitProcess(0);
	}
	else
	{
		if (MessageBoxW(NULL, L"Really?.", L"pentacyanocyclopentadiene.exe - Last Warning", MB_YESNO | MB_ICONEXCLAMATION) == IDNO)
		{
			ExitProcess(0);
		}
		else
		{
			Sleep(1000);
			CreateThread(0, 0, fakeerror, 0, 0, 0);
			Sleep(5000);
			Sleep(100);
			Sleep(10);
			HANDLE thread1 = CreateThread(0, 0, patblt, 0, 0, 0);
			HANDLE thread1dot1 = CreateThread(0, 0, waves1, 0, 0, 0);
			sound1(8000, 30);
			TerminateThread(thread1dot1, 0);
			CloseHandle(thread1dot1);
			InvalidateRect(0, 0, 0);
			RedrawWindow(0, 0, 0, 133);
			Sleep(100);
			HANDLE thread2 = CreateThread(0, 0, smelt, 0, 0, 0);
			sound2(8000, 30);
			TerminateThread(thread2, 0);
			CloseHandle(thread2);
			InvalidateRect(0, 0, 0);
			RedrawWindow(0, 0, 0, 133);
			Sleep(100);
			HANDLE thread3 = CreateThread(0, 0, listopad, 0, 0, 0);
			sound3(11025, 30);
			TerminateThread(thread1, 0);
			CloseHandle(thread1);
			TerminateThread(thread3, 0);
			CloseHandle(thread3);
			InvalidateRect(0, 0, 0);
			RedrawWindow(0, 0, 0, 133);
			Sleep(100);
			HANDLE thread4 = CreateThread(0, 0, payload1, 0, 0, 0);
			HANDLE thread4dot1 = CreateThread(0, 0, textout1, 0, 0, 0);
			sound4(11025, 30);
			InvalidateRect(0, 0, 0);
			RedrawWindow(0, 0, 0, 133);
			Sleep(100);
			HANDLE thread5 = CreateThread(0, 0, redraw, 0, 0, 0);
			HANDLE thread5dot1 = CreateThread(0, 0, icon, 0, 0, 0);
			HANDLE thread5dot2 = CreateThread(0, 0, wef, 0, 0, 0);
			sound5(44100, 30);
			TerminateThread(thread4, 0);
			CloseHandle(thread4);
			TerminateThread(thread5, 0);
			CloseHandle(thread5);
			InvalidateRect(0, 0, 0);
			RedrawWindow(0, 0, 0, 133);
			Sleep(100);
			HANDLE thread6 = CreateThread(0, 0, shader1, 0, 0, 0);
			sound6(48000, 30);
			TerminateThread(thread6, 0);
			CloseHandle(thread6);
			InvalidateRect(0, 0, 0);
			RedrawWindow(0, 0, 0, 133);
			Sleep(100);
			HANDLE thread7 = CreateThread(0, 0, payload2, 0, 0, 0);
			sound7(44100, 30);
			TerminateThread(thread7, 0);
			CloseHandle(thread7);
			InvalidateRect(0, 0, 0);
			RedrawWindow(0, 0, 0, 133);
			Sleep(100);
			HANDLE thread8 = CreateThread(0, 0, payload3, 0, 0, 0);
			HANDLE thread8dot1 = CreateThread(0, 0, cubes, 0, 0, 0);
			sound8(8000, 30);
			TerminateThread(thread8, 0);
			CloseHandle(thread8);
			InvalidateRect(0, 0, 0);
			RedrawWindow(0, 0, 0, 133);
			Sleep(100);
			HANDLE thread9 = CreateThread(0, 0, shader2, 0, 0, 0);
			sound9(8000, 30);
			TerminateThread(thread9, 0);
			CloseHandle(thread9);
			InvalidateRect(0, 0, 0);
			RedrawWindow(0, 0, 0, 133);
			Sleep(100);
			HANDLE thread10 = CreateThread(0, 0, shader3, 0, 0, 0);
			sound10(8000, 30);
			TerminateThread(thread10, 0);
			CloseHandle(thread10);
			InvalidateRect(0, 0, 0);
			RedrawWindow(0, 0, 0, 133);
			Sleep(100);
			HANDLE thread11 = CreateThread(0, 0, shader4, 0, 0, 0);
			sound11(8000, 30);
			TerminateThread(thread11, 0);
			CloseHandle(thread11);
			InvalidateRect(0, 0, 0);
			RedrawWindow(0, 0, 0, 133);
			Sleep(100);
			HANDLE thread12 = CreateThread(0, 0, waves2, 0, 0, 0);
			sound12(8000, 30);
			TerminateThread(thread12, 0);
			CloseHandle(thread12);
			InvalidateRect(0, 0, 0);
			RedrawWindow(0, 0, 0, 133);
			Sleep(100);
		}
	}
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
